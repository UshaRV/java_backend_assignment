package com.usha.assignment1.repositories;

import org.springframework.data.repository.CrudRepository;

import com.usha.assignment1.entities.Team;

public interface TeamRepository extends CrudRepository<Team, Long> {

}
