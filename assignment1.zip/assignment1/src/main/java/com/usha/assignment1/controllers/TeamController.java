package com.usha.assignment1.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.usha.assignment1.entities.Team;
import com.usha.assignment1.repositories.TeamRepository;

@RestController
public class TeamController {
	@Autowired
	private TeamRepository teamRepo;
	
	@PostMapping("/team/create")
	public void createTeam(@RequestBody Team team) {
		teamRepo.save(team);
	}

	@GetMapping("/team/findById/{id}")
	public Team findTeam(@PathVariable Long id) {
		Team result = teamRepo.findById(id).get();
		return result;
	}

	@GetMapping("/team/list")
	public List<Team> allTeams() {
		return (List<Team>) teamRepo.findAll();
	}

	@RequestMapping("/team/{id}")
	public void updateTeam(@PathVariable Long id, @RequestBody Team team) {
		Team newTeam = new Team();
		newTeam.setName(team.getName());
		newTeam.setLocation(team.getLocation());
		newTeam.setId(team.getId());
		teamRepo.save(newTeam);
	}

	@DeleteMapping("/team/{id}")
	public void deleteTeam(@PathVariable Long id) {
		teamRepo.deleteById(id);
	}

}
